enum MemberRank { r5, r4, r3, r2, r1 }
